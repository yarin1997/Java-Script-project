function sum(num1, num2) {
    return num1 + num2;
}
console.log(sum(45, 23));
function avrage(arr) {
    var sum = 0;
    for (var i = 0; i < arr.length; i++) {
        sum = sum + arr[i];
    }
    return sum / arr.length;
}
console.log(avrage([1, 2, 3]));
